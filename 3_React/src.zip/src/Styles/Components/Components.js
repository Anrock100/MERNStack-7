import React from "react";

class Component1 extends React.Component{
    render(){
        return(
            <div>
                <h1>Component-1</h1>
                <h2>Personal Info</h2>
                <p>ID : 1</p>
                <p>NAME : Your NAME</p>
            </div>
        );
    }
};

export default Component1;
import React from "react";
import Component1 from "./Components/Component1";
import './Styles.css';

var Styles = ()=>{
    return(
        <div className="comp">
            <Component1/>
        </div>
    );
}
export default Styles;
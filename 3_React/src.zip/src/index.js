import ReactDOM from "react-dom";
// import Comp1 from './Components/Component1';
// import Comp2 from './Components/Component2';
// import Components from "./Components/Components";
import Styles from "./Styles/Styles";
import './index.css';

// Style-1
// ReactDOM.render(<h1>Welcome to Reactjs</h1>, document.getElementById('root'));

// Style-2
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<h1>Welcome to Reactjs</h1>);

// Render Component
const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<Components/>);
root.render(<Styles/>);
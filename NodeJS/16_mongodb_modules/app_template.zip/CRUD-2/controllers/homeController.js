

var homeController = (request, response) => {
    response.render('home');//display all persons in home.ejs.
};

export { homeController };